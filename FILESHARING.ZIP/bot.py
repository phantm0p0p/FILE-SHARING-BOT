from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pymongo import MongoClient
import config
import string
import random
import logging

# Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize the bot
bot = Client("file_sharing_bot", api_id=config.api_id, api_hash=config.api_hash, bot_token=config.bot_token)

# Initialize MongoDB
mongo_client = MongoClient(config.MONGO_URL)
db = mongo_client["file_sharing_bot"]
collection = db["files"]
batch_collection = db["batches"]

# Function to generate a unique link
def generate_unique_link():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=10))

from pyrogram import filters, InlineKeyboardButton, InlineKeyboardMarkup

@bot.on_message(filters.private & filters.user(lambda u: u.id in config.OWNER_IDS) & filters.command("upload"))
async def upload_command(client, message):
    if message.reply_to_message:
        await upload_content(client, message.reply_to_message, message.chat.id)

async def upload_content(client, message, reply_chat_id=None):
    try:
        content_type = None
        file_id = None
        chat_id = config.CHANNEL_ID  # Use channel ID from the configuration

        if message.document:
            content_type = 'document'
            file_id = message.document.file_id
            sent_message = await bot.send_document(chat_id, file_id)
        elif message.photo:
            content_type = 'photo'
            file_id = message.photo.file_id
            sent_message = await bot.send_photo(chat_id, file_id)
        elif message.video:
            content_type = 'video'
            file_id = message.video.file_id
            sent_message = await bot.send_video(chat_id, file_id)
        elif message.voice:
            content_type = 'voice'
            file_id = message.voice.file_id
            sent_message = await bot.send_voice(chat_id, file_id)
        elif message.audio:
            content_type = 'audio'
            file_id = message.audio.file_id
            sent_message = await bot.send_audio(chat_id, file_id)
        elif message.text:
            content_type = 'text'
            sent_message = await bot.send_message(chat_id, message.text)
        else:
            await message.reply_text("🚫 Unsupported content type.")
            return

        # Generate a unique link
        unique_link = generate_unique_link()

        # Store the content info in MongoDB
        collection.insert_one({
            "content_type": content_type,
            "file_id": file_id if content_type != 'text' else None,
            "text": message.text if content_type == 'text' else None,
            "message_id": sent_message.id,
            "unique_link": unique_link
        })

        # Get the bot's username
        bot_info = await bot.get_me()
        bot_username = bot_info.username

        # Create the share link
        share_link = f"https://t.me/{bot_username}?start={unique_link}"

        # Create inline keyboard button
        reply_markup = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 Share Link", url=f"https://telegram.me/share/url?url={share_link}")]
        ])

        # Send the link to the owner with inline button
        if reply_chat_id:
            await bot.send_message(
                reply_chat_id,
                "✅ Content uploaded successfully. Share this link to access the content:",
                reply_markup=reply_markup
            )
        else:
            await message.reply_text(
                "✅ Content uploaded successfully. Share this link to access the content:",
                reply_markup=reply_markup
            )

        # Edit the message in the channel to include the inline button
        await bot.edit_message_reply_markup(
            chat_id, 
            sent_message.id,
            reply_markup=reply_markup
        )

        logger.info(f"Content uploaded successfully: {unique_link}")

    except Exception as e:
        logger.error(f"Failed to upload content: {e}")
        await message.reply_text("⚠️ An error occurred while uploading the content.")

# Handler to fetch and send the content using the unique link
@bot.on_message(filters.private & filters.command("start"))
async def send_content(client, message):
    try:
        if len(message.command) > 1:
            unique_link = message.command[1]
            content_data = collection.find_one({"unique_link": unique_link})

            if content_data:
                if content_data["content_type"] == "text":
                    await bot.send_message(message.chat.id, content_data["text"])
                else:
                    await bot.copy_message(message.chat.id, config.CHANNEL_ID, content_data["message_id"])
                
                # Check if the user is the bot owner
                if message.from_user.id == config.OWNER_ID:
                    logger.info(f"Bot owner requested content for link: {unique_link}")
                    return  # Do not re-upload the content to the channel or send it again to the owner

            else:
                await message.reply_text("❌ Invalid or expired link.")
        else:
            # If the user is not the owner and no unique link is provided
            if message.from_user.id != config.OWNER_ID:
                image_url = "https://telegra.ph/file/106f5ee9d1d1149d3b84b.jpg"
                await bot.send_photo(
                    chat_id=message.chat.id,
                    photo=image_url,
                    caption=(
                        "📁 Sorry, but this is a file sharing bot!\n"
                        "🔒 You probably don't have access to me.\n\n"
                        "🤖 This bot is powered by @DominosXd"
                    )
                )
            else:
                await message.reply_text("🔗 Please provide a valid link.")
        
        logger.info(f"Content sent for link: {unique_link}")

    except Exception as e:
        logger.error(f"Failed to send content: {e}")
        await message.reply_text("⚠️ Failed to send content. Please try again later.")


# Start the bot
bot.run()
