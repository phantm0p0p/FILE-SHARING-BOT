from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

api_id = os.getenv("API_ID")
api_hash = os.getenv("API_HASH")
bot_token = os.getenv("BOT_TOKEN")
MONGO_URL = os.getenv("MONGO_URL")

# Parse OWNER_IDS from environment variable
OWNER_IDS = list(map(int, os.getenv("OWNER_IDS", "").split(",")))

CHANNEL_ID = int(os.getenv("CHANNEL_ID"))
