# File Sharing Bot

## Overview

This bot allows you to upload and share various types of content through Telegram. The bot uses MongoDB for storage and requires specific environment variables to be set up properly.

## Environment Variables

To run the bot, you need to create a `.env` file in the same directory as your `config.py` file. This file should contain the following environment variables:

### `.env` File Template

```env
# Telegram API credentials
API_ID=your_api_id_here
API_HASH=your_api_hash_here
BOT_TOKEN=your_bot_token_here

# MongoDB connection URL
MONGO_URL=your_mongo_db_connection_url_here

# List of bot owner IDs (comma-separated)
OWNER_IDS=owner_id1,owner_id2

# Telegram channel ID where content will be uploaded, {Also Ensure to add bot on that Database channel and make him admin}

CHANNEL_ID=your_channel_id_here
